package in.co.bel.ims.initial.service.exception;

public class DuplicatePassException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DuplicatePassException(String message) {
		super(message);
	}

}
