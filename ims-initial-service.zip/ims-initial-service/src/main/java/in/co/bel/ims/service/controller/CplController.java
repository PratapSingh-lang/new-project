package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.Cpl;
import in.co.bel.ims.data.repository.CplRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/cpl")
public class CplController extends ImsServiceTemplate<Cpl, CplRepository>{

}
