package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.Appendix;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface AppendixRepository extends ImsJPATemplate<Appendix> {
   
}

