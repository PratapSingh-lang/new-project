package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.GuestType;
import in.co.bel.ims.data.repository.GuestTypeRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/guestType")
public class GuestTypeController extends ImsServiceTemplate<GuestType, GuestTypeRepository>{

}
