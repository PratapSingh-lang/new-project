package in.co.bel.ims.initial.dto;

import java.util.List;
import java.util.Map;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class PassRequest {

	private int eventId;
	private int ministryId;
	private int designationId;
	private int inviteeId;
	private int noOfPasses;
	private int enclosureId;
	private Map<Integer, Integer> noOfPassesInEnclosure;
	private Character organiser;
	private Map<Integer, Integer> organiserInviteToEnclosure;
	private List<Integer> guests;
}
