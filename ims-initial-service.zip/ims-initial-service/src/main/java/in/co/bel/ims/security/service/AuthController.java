package in.co.bel.ims.security.service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.ImsUser;
import in.co.bel.ims.data.entity.SessionManagement;
import in.co.bel.ims.data.repository.ImsUserRepository;
import in.co.bel.ims.data.repository.RoleRepository;
import in.co.bel.ims.data.repository.SessionManagementRepository;
import in.co.bel.ims.initial.dto.JwtResponse;
import in.co.bel.ims.initial.dto.LoginRequest;
import in.co.bel.ims.security.jwt.JwtUtils;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/app/api/auth")
public class AuthController {
	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	ImsUserRepository userRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	JwtUtils jwtUtils;

	@Autowired
	private SessionManagementRepository trackerRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	ImsBruteForceProtectionService bruteForceProtectionService;

	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {

		String username = loginRequest.getUsername();
		String password = loginRequest.getPassword();

		ImsUser ImsUser = userRepository.getByMobileNoAndDeleted(username, false);
		if (ImsUser != null) {
			
			System.out.println("User Logged-In Successfully! : "+username);
			if (ImsUser.getLoggedIn() == 0 || releaseLoggedInUser(ImsUser)) {
				if (ImsUser.getLocked() && !releaseLockedUser(ImsUser)) {
					return (ResponseEntity<?>) ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(
							"Your account has been locked due to 3 failed attempts. It will be unlocked after 24 hours.");
				} else {
					if (passwordEncoder.matches(password, ImsUser.getPassword())) {
						bruteForceProtectionService.resetBruteForceCounter(username);
						Authentication authentication = authenticationManager
								.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUsername(),
										loginRequest.getPassword()));

						SecurityContextHolder.getContext().setAuthentication(authentication);

						String jwt = jwtUtils.generateJwtToken(authentication);

						SessionManagement sessionTracker = new SessionManagement();
						sessionTracker.setToken(jwt);
						trackerRepository.save(sessionTracker);

						UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
						List<String> roles = userDetails.getAuthorities().stream().map(item -> item.getAuthority())
								.collect(Collectors.toList());

						ImsUser user = userRepository.getByMobileNoAndDeleted(loginRequest.getUsername(), false);
						if (user != null) {
							user.setLoggedIn(1);
							userRepository.save(user);
						}

						return ResponseEntity.ok(new JwtResponse(jwt, userDetails.getId(), userDetails.getUsername(),
								userDetails.getEmail(), roles, userDetails.getStatus()));
					} else {
						bruteForceProtectionService.registerLoginFailure(username);
						return (ResponseEntity<?>) ResponseEntity.status(HttpStatus.UNAUTHORIZED)
								.body("Invalid Username/Password");
					}
				}
			} else
				return (ResponseEntity<?>) ResponseEntity.status(HttpStatus.UNAUTHORIZED)
						.body("User already logged-in!");
		} else
			return (ResponseEntity<?>) ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Username/Password");

	}

	private boolean releaseLoggedInUser(ImsUser user) {

		if (user.getLastLogin() != null) {
			LocalDateTime login2Hrs = user.getLastLogin().plus(30, ChronoUnit.MINUTES);
			if (login2Hrs.isBefore(LocalDateTime.now())) {
				user.setLoggedIn(0);
				user.setLastLogin(null);
				userRepository.save(user);

				return true;
			}
		}

		return false;
	}

	private boolean releaseLockedUser(ImsUser user) {
		if (user.getLastLocked() != null) {
			LocalDateTime locked24Hrs = user.getLastLocked().plus(24, ChronoUnit.HOURS);
			if (locked24Hrs.isBefore(LocalDateTime.now())) {
				user.setLocked(false);
				user.setLastLocked(null);
				user.setLoginAttempts(0);
				userRepository.save(user);
				return true;
			}
		}
		return false;
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(Exception.class)
	public String handleCustomExceptions(Exception ex) {
		ex.printStackTrace();
		return ex.getMessage();
	}
}
