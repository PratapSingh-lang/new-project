package in.co.bel.ims.infra.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MlaMpUserData {
	
	private String empId;
	private String constituencyOrState;
	private String salutation;
	private String name;
	private String mobileNo;
	private String email;
	private String maritalStatus;
	private String address;
	private String remarks;

}
