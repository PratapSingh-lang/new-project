package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.Role;
import in.co.bel.ims.data.repository.RoleRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/role")
public class RoleController extends ImsServiceTemplate<Role, RoleRepository>{

}
