package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.EnclosureCplMapping;
import in.co.bel.ims.data.repository.EnclosureCplMappingRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/enclosureCplMapping")
public class EnclosureCplMappingController extends ImsServiceTemplate<EnclosureCplMapping, EnclosureCplMappingRepository>{

}
