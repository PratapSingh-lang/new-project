package in.co.bel.ims.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.co.bel.ims.data.entity.ImsUser;
import in.co.bel.ims.data.repository.ImsUserRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
  @Autowired
  ImsUserRepository userRepository;

  @Override
  @Transactional
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		ImsUser user = userRepository.getByMobileNoAndDeleted(username, false);
		return UserDetailsImpl.build(user);
	}

}
