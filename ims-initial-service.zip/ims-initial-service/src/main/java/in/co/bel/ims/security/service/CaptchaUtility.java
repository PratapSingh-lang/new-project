package in.co.bel.ims.security.service;

import java.net.URI;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
public class CaptchaUtility extends AbstractCaptchaUtility {
	

    protected RestTemplate restTemplate = new RestTemplate();

	public boolean processResponse(final String response) {

		boolean status = false;
		securityCheck(response);

		final URI verifyUri = URI
				.create(String.format(RECAPTCHA_URL_TEMPLATE, getReCaptchaSecret(), response, getClientIP()));
		try {
			final GoogleResponse googleResponse = restTemplate.getForObject(verifyUri, GoogleResponse.class);

			if (googleResponse.isSuccess()) {
				status = true;
			}
		} catch (RestClientException rce) {
			throw new ReCaptchaInvalidException("Registration unavailable at this time.  Please try again later.", rce);
		}

		return status;
	}
}