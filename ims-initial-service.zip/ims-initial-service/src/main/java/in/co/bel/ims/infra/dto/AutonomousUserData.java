package in.co.bel.ims.infra.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AutonomousUserData {

	private String empId;
	private String salutation;
	private String name;
	private String designation;
	private String payLevel;
	private String basicPay;
	private String mobileNo;
	private String email;
	private String maritalStatus;
	private String officialAddress;
	private String residentialAddress;
	private String seatingPreference;
	private String remarks;
	private String equivalentStatus;
}
