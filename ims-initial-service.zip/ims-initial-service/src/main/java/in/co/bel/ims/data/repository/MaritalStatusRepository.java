package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.MaritalStatus;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface MaritalStatusRepository extends ImsJPATemplate<MaritalStatus> {
   
}

