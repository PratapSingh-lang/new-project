package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.Article;
import in.co.bel.ims.data.repository.ArticleRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/article")
public class ArticleController extends ImsServiceTemplate<Article, ArticleRepository>{

}
