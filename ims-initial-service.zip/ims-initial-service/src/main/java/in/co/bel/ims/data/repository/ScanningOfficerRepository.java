package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.ScanningOfficer;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface ScanningOfficerRepository extends ImsJPATemplate<ScanningOfficer> {
   
}

