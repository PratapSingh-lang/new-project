package in.co.bel.ims.infra.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GuestUserData {

	private String salutation;
	private String name;
	private String mobileNo;
	private String email;
	private String nationality;
	private String residentialAddress;
	private String govtIdNumber;
	private String remarks;
}
