package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.MaritalStatus;
import in.co.bel.ims.data.repository.MaritalStatusRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/maritalStatus")
public class MaritalStatusController extends ImsServiceTemplate<MaritalStatus, MaritalStatusRepository>{

}
