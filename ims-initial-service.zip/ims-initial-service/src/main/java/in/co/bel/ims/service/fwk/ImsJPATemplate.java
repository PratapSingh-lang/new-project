package in.co.bel.ims.service.fwk;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface ImsJPATemplate<T> extends JpaRepository<T, Integer> {
	
	public List<T> findAllByDeleted(Sort sort, boolean isDeleted);
	public List<T> findAllByDeleted(boolean isDeleted);
	
}