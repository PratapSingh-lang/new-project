package in.co.bel.ims.infra.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MinistryUserData {

	private String empId;
	private String salutation;
	private String name;
	private String designation;
	private String payLevel;
	private String basicPay;
	private String mobileNo;
	private String email;
	private String maritalStatus;
	private String officialAddress;
	private String residentialAddress;
	private String seatingPreference;
	private String remarks;
}
