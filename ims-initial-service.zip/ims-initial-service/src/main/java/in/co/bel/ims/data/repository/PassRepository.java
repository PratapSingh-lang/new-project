package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.Pass;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface PassRepository extends ImsJPATemplate<Pass> {
   
}

