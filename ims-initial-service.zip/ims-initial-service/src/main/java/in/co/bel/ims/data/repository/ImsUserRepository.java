package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.ImsUser;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface ImsUserRepository extends ImsJPATemplate<ImsUser> {
	
	public ImsUser getByMobileNoAndDeleted(String mobileNo, boolean isDeleted);
}

