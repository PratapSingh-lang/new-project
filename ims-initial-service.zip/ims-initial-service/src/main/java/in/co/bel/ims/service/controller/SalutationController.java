package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.Salutation;
import in.co.bel.ims.data.repository.SalutationRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/salutation")
public class SalutationController extends ImsServiceTemplate<Salutation, SalutationRepository>{

}
