package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.UserType;
import in.co.bel.ims.data.repository.UserTypeRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/userType")
public class UserTypeController extends ImsServiceTemplate<UserType, UserTypeRepository>{

}
