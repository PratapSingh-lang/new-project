package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.Role;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface RoleRepository extends ImsJPATemplate<Role> {
   
}

