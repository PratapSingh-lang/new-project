package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.CplType;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface CplTypeRepository extends ImsJPATemplate<CplType> {
   
}

