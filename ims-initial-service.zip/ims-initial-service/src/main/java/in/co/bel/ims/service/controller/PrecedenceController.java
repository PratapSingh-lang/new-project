package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.Precedence;
import in.co.bel.ims.data.repository.PrecedenceRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/precedence")
public class PrecedenceController extends ImsServiceTemplate<Precedence, PrecedenceRepository>{

}
