package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.PassStatus;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface PassStatusRepository extends ImsJPATemplate<PassStatus> {
   
}

