package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.Notification;
import in.co.bel.ims.data.repository.NotificationRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/notification")
public class NotificationController extends ImsServiceTemplate<Notification, NotificationRepository>{

}
