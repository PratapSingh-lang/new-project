package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.OrganizationGroup;
import in.co.bel.ims.data.repository.OrganizationGroupRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/organizationGroup")
public class OrganizationGroupController extends ImsServiceTemplate<OrganizationGroup, OrganizationGroupRepository>{

}
