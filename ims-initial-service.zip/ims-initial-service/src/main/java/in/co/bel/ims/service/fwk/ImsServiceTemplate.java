package in.co.bel.ims.service.fwk;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import in.co.bel.ims.data.util.ImsJpaUpdateUtil;

public class ImsServiceTemplate<T, S extends ImsJPATemplate<T>> {

	@Autowired
	private S s;

	@GetMapping("/getAll")
	public List<T> getAll() {
		return s.findAllByDeleted(Sort.by(Order.asc("id")), false);
	}

	@GetMapping("/getById/{id}")
	public Optional<T> getById(@PathVariable int id) {
		return s.findById(id);
	}

	@PostMapping("/save")
	public T create(@Valid @RequestBody T t) {
		return s.save(t);
	}

	@DeleteMapping("/deleteById/{id}")
	public void delete(@PathVariable int id) {
		T entityToDelete = s.findById(id).get();
		try {
			entityToDelete.getClass().getMethod("setDeleted", Boolean.class).invoke(entityToDelete, true);
			s.save(entityToDelete);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException
				| SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@SuppressWarnings("unchecked")
	@PutMapping("/update")
	public T update(@Valid @RequestBody T t) {

		Object sourceEntity = null;
		Object entityToUpdate = null;

		try {
			sourceEntity = s.findById((int) t.getClass().getMethod("getId").invoke(t));
			entityToUpdate = sourceEntity.getClass().getMethod("get").invoke(sourceEntity);
			ImsJpaUpdateUtil.copyEntityProperties(t, entityToUpdate);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException
				| SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s.save((T)entityToUpdate);
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(Exception.class)
	public String handleCustomExceptions(Exception ex) {
		ex.printStackTrace();
		return ex.getMessage();
	}
}
