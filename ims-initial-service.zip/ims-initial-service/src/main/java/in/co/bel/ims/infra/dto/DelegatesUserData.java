package in.co.bel.ims.infra.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DelegatesUserData {

	private String empId;
	private String countryOrOrganization;
	private String salutation;
	private String name;
	private String positionInMissionOrConsulate;
	private String mobileNo;
	private String email;
	private String maritalStatus;
	private String officialAddress;
	private String remarks;
}
