package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.UserType;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface UserTypeRepository extends ImsJPATemplate<UserType> {
   
}

