package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.EnclosureCplMapping;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface EnclosureCplMappingRepository extends ImsJPATemplate<EnclosureCplMapping> {
   
}

