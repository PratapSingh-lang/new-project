package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.EnclosurePassTypeMapping;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface EnclosurePassTypeMappingRepository extends ImsJPATemplate<EnclosurePassTypeMapping> {
   
}

