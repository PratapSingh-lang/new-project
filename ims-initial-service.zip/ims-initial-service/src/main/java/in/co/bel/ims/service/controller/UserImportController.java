package in.co.bel.ims.service.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import in.co.bel.ims.data.repository.ImsUserRepository;
import in.co.bel.ims.infra.util.ExcelTemplateParser;

@RestController
@RequestMapping("/import")
public class UserImportController {


	@Autowired
	private ImsUserRepository imsUserRepository;
	
	
	@PostMapping("/importAnnexAUsers")
	public void importAnnexAUsers(@RequestParam("file") MultipartFile file) {
		
		try {
			imsUserRepository.saveAll(ExcelTemplateParser.parseTemplateA(file.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@PostMapping("/importAnnexBUsers")
	public void importAnnexBUsers(@RequestParam("file") MultipartFile file) {
		try {
			imsUserRepository.saveAll(ExcelTemplateParser.parseTemplateB(file.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@PostMapping("/importAnnexAUsers")
	public void importAnnexCUsers(@RequestParam("file") MultipartFile file) {
		try {
			imsUserRepository.saveAll(ExcelTemplateParser.parseTemplateC(file.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@PostMapping("/importAnnexDUsers")
	public void importAnnexDUsers(@RequestParam("file") MultipartFile file) {
		try {
			imsUserRepository.saveAll(ExcelTemplateParser.parseTemplateD(file.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@PostMapping("/importAnnexEUsers")
	public void importAnnexEUsers(@RequestParam("file") MultipartFile file) {
		try {
			imsUserRepository.saveAll(ExcelTemplateParser.parseTemplateE(file.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@PostMapping("/importAnnexFUsers")
	public void importAnnexFUsers(@RequestParam("file") MultipartFile file) {
		try {
			imsUserRepository.saveAll(ExcelTemplateParser.parseTemplateF(file.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
