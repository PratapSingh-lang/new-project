package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.Venue;
import in.co.bel.ims.data.repository.VenueRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/venue")
public class VenueController extends ImsServiceTemplate<Venue, VenueRepository>{

}
