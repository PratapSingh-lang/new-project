package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.SessionManagement;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface SessionManagementRepository extends ImsJPATemplate<SessionManagement> {
   
	public SessionManagement findByTokenAndValid(String token, boolean valid);
}

