package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.Article;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface ArticleRepository extends ImsJPATemplate<Article> {
   
}

