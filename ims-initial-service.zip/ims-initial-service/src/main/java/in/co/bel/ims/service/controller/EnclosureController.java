package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.Enclosure;
import in.co.bel.ims.data.repository.EnclosureRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/enclosure")
public class EnclosureController extends ImsServiceTemplate<Enclosure, EnclosureRepository>{

}
