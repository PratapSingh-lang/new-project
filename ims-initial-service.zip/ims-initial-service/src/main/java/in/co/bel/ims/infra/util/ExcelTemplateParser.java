package in.co.bel.ims.infra.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import in.co.bel.ims.data.entity.EnclosureGroup;
import in.co.bel.ims.data.entity.ImsUser;
import in.co.bel.ims.data.entity.MaritalStatus;
import in.co.bel.ims.data.entity.PayLevel;
import in.co.bel.ims.data.entity.Precedence;
import in.co.bel.ims.data.entity.Salutation;

public class ExcelTemplateParser {
	

	
	// Appendix A - Ministry Users excel template parsing.
	public static List<ImsUser> parseTemplateA(InputStream fileStream) {

		List<ImsUser> imsUserList = new ArrayList<>();
		try {
			Workbook workbook = new XSSFWorkbook(fileStream);
			Sheet sheet = workbook.getSheetAt(0);

			sheet.forEach(row -> {
				ImsUser imsUser = new ImsUser();
				row.cellIterator().forEachRemaining(cell -> {
					switch (cell.getColumnIndex()) {
					case ExcelTemplateConstants.APDX_A_EMP_ID_COLUMN_INDEX:
						imsUser.setEmpNo(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_A_SALUTAION_COLUMN_INDEX:
						imsUser.setSalutation(new Salutation(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_A_NAME_COLUMN_INDEX:
						imsUser.setName(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_A_DESIGNATION_COLUMN_INDEX:
						imsUser.setDesignation(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_A_PAY_LEVEL_COLUMN_INDEX:
						imsUser.setPayLevel(new PayLevel(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_A_BASIC_PAY_COLUMN_INDEX:
						imsUser.setBasicPay(cell.getNumericCellValue());
						break;
					case ExcelTemplateConstants.APDX_A_MOBILE_NO_COLUMN_INDEX:
						imsUser.setMobileNo(
								(cell.getCellType() == CellType.NUMERIC) ? String.valueOf(cell.getNumericCellValue())
										: cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_A_EMAIL_COLUMN_INDEX:
						imsUser.setEmail(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_A_MARITAL_STATUS_COLUMN_INDEX:
						imsUser.setMaritalStatus(new MaritalStatus(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_A_OFFICIAL_ADDRESS_COLUMN_INDEX:
						imsUser.setOfficeAddress(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_A_RESIDENTIAL_ADDRESS_COLUMN_INDEX:
						imsUser.setResidentialAddress(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_A_SEATING_PREFERENCE_COLUMN_INDEX:
						imsUser.setEnclosureGroup(new EnclosureGroup(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_A_REMARKS_COLUMN_INDEX:
						imsUser.setRemarks(cell.getStringCellValue());
						break;
					}

				});
				
				imsUserList.add(imsUser);
			});
			workbook.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return imsUserList;
	}

	// Appendix B - Autonomous/PSU Users excel template parsing.
	public static List<ImsUser> parseTemplateB(InputStream fileStream) {

		List<ImsUser> imsUserList = new ArrayList<>();
		try {
			Workbook workbook = new XSSFWorkbook(fileStream);
			Sheet sheet = workbook.getSheetAt(0);

			sheet.forEach(row -> {
				ImsUser imsUser = new ImsUser();
				row.cellIterator().forEachRemaining(cell -> {
					switch (cell.getColumnIndex()) {
					case ExcelTemplateConstants.APDX_B_EMP_ID_COLUMN_INDEX:
						imsUser.setEmpNo(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_B_SALUTAION_COLUMN_INDEX:
						imsUser.setSalutation(new Salutation(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_B_NAME_COLUMN_INDEX:
						imsUser.setName(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_B_DESIGNATION_COLUMN_INDEX:
						imsUser.setDesignation(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_B_EQUI_STATUS_COLUMN_INDEX:
						imsUser.setEquivalentStatus(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_B_PAY_LEVEL_COLUMN_INDEX:
						imsUser.setPayLevel(new PayLevel(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_B_BASIC_PAY_COLUMN_INDEX:
						imsUser.setBasicPay(cell.getNumericCellValue());
						break;
					case ExcelTemplateConstants.APDX_B_MOBILE_NO_COLUMN_INDEX:
						imsUser.setMobileNo(
								(cell.getCellType() == CellType.NUMERIC) ? String.valueOf(cell.getNumericCellValue())
										: cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_B_EMAIL_COLUMN_INDEX:
						imsUser.setEmail(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_B_MARITAL_STATUS_COLUMN_INDEX:
						imsUser.setMaritalStatus(new MaritalStatus(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_B_OFFICIAL_ADDRESS_COLUMN_INDEX:
						imsUser.setOfficeAddress(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_B_RESIDENTIAL_ADDRESS_COLUMN_INDEX:
						imsUser.setResidentialAddress(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_B_SEATING_PREFERENCE_COLUMN_INDEX:
						imsUser.setEnclosureGroup(new EnclosureGroup(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_B_REMARKS_COLUMN_INDEX:
						imsUser.setRemarks(cell.getStringCellValue());
						break;
					}

				});
				
				imsUserList.add(imsUser);
			});
			workbook.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return imsUserList;
	}
	
	// Appendix C - Commission/Committees Users excel template parsing.
	public static List<ImsUser> parseTemplateC(InputStream fileStream) {

		List<ImsUser> imsUserList = new ArrayList<>();
		try {
			Workbook workbook = new XSSFWorkbook(fileStream);
			Sheet sheet = workbook.getSheetAt(0);

			sheet.forEach(row -> {
				ImsUser imsUser = new ImsUser();
				row.cellIterator().forEachRemaining(cell -> {
					switch (cell.getColumnIndex()) {
					case ExcelTemplateConstants.APDX_C_EMP_ID_COLUMN_INDEX:
						imsUser.setEmpNo(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_C_SALUTAION_COLUMN_INDEX:
						imsUser.setSalutation(new Salutation(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_C_NAME_COLUMN_INDEX:
						imsUser.setName(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_C_DESIGNATION_COLUMN_INDEX:
						imsUser.setDesignation(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_C_EQUI_STATUS_COLUMN_INDEX:
						imsUser.setEquivalentStatus(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_C_TAB_OF_PRECEDENCE_COLUMN_INDEX:
						imsUser.setPrecedence(new Precedence(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_C_PAY_LEVEL_COLUMN_INDEX:
						imsUser.setPayLevel(new PayLevel(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_C_BASIC_PAY_COLUMN_INDEX:
						imsUser.setBasicPay(cell.getNumericCellValue());
						break;
					case ExcelTemplateConstants.APDX_C_MOBILE_NO_COLUMN_INDEX:
						imsUser.setMobileNo(
								(cell.getCellType() == CellType.NUMERIC) ? String.valueOf(cell.getNumericCellValue())
										: cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_C_EMAIL_COLUMN_INDEX:
						imsUser.setEmail(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_C_MARITAL_STATUS_COLUMN_INDEX:
						imsUser.setMaritalStatus(new MaritalStatus(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_C_OFFICIAL_ADDRESS_COLUMN_INDEX:
						imsUser.setOfficeAddress(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_C_RESIDENTIAL_ADDRESS_COLUMN_INDEX:
						imsUser.setResidentialAddress(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_C_SEATING_PREFERENCE_COLUMN_INDEX:
						imsUser.setEnclosureGroup(new EnclosureGroup(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_C_REMARKS_COLUMN_INDEX:
						imsUser.setRemarks(cell.getStringCellValue());
						break;
					}

				});
				
				imsUserList.add(imsUser);
			});
			workbook.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return imsUserList;
	}

	// Appendix D - Guest Users excel template parsing.
	public static List<ImsUser> parseTemplateD(InputStream fileStream) {

		List<ImsUser> guestUserDataList = new ArrayList<>();
		try {
			Workbook workbook = new XSSFWorkbook(fileStream);
			Sheet sheet = workbook.getSheetAt(0);

			sheet.forEach(row -> {
				ImsUser guestUserData = new ImsUser();
				row.cellIterator().forEachRemaining(cell -> {
					switch (cell.getColumnIndex()) {
					
					case ExcelTemplateConstants.APDX_D_SALUTAION_COLUMN_INDEX:
						guestUserData.setSalutation(new Salutation(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_D_NAME_COLUMN_INDEX:
						guestUserData.setName(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_D_MOBILE_NO_COLUMN_INDEX:
						guestUserData.setMobileNo(
								(cell.getCellType() == CellType.NUMERIC) ? String.valueOf(cell.getNumericCellValue())
										: cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_D_EMAIL_COLUMN_INDEX:
						guestUserData.setEmail(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_D_NATIONALITY_COLUMN_INDEX:
						guestUserData.setNationality(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_D_ID_NUMBER_COLUMN_INDEX:
						guestUserData.setIdProofNo(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_D_RESIDENTIAL_ADDRESS_COLUMN_INDEX:
						guestUserData.setResidentialAddress(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_D_REMARKS_COLUMN_INDEX:
						guestUserData.setRemarks(cell.getStringCellValue());
						break;
					}

				});
				
				guestUserDataList.add(guestUserData);
			});
			workbook.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return guestUserDataList;
	}

	
	// Appendix E - Delegates/Consulate Users excel template parsing.
	public static List<ImsUser> parseTemplateE(InputStream fileStream) {

		List<ImsUser> delegatesUserDataList = new ArrayList<>();
		try {
			Workbook workbook = new XSSFWorkbook(fileStream);
			Sheet sheet = workbook.getSheetAt(0);

			sheet.forEach(row -> {
				ImsUser delegatesUserData = new ImsUser();
				row.cellIterator().forEachRemaining(cell -> {
					switch (cell.getColumnIndex()) {
					case ExcelTemplateConstants.APDX_E_EMP_ID_COLUMN_INDEX:
						delegatesUserData.setEmpNo(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_E_COUNTRY_ORGANIZATION:
						delegatesUserData.setNationality(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_E_SALUTAION_COLUMN_INDEX:
						delegatesUserData.setSalutation(new Salutation(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_E_NAME_COLUMN_INDEX:
						delegatesUserData.setName(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_E_POSITION_COLUMN_INDEX:
						delegatesUserData.setPositionMissionConsulate(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_E_MOBILE_NO_COLUMN_INDEX:
						delegatesUserData.setMobileNo(
								(cell.getCellType() == CellType.NUMERIC) ? String.valueOf(cell.getNumericCellValue())
										: cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_E_EMAIL_COLUMN_INDEX:
						delegatesUserData.setEmail(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_E_MARITAL_STATUS_COLUMN_INDEX:
						delegatesUserData.setMaritalStatus(new MaritalStatus(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_E_OFFICIAL_ADDRESS_COLUMN_INDEX:
						delegatesUserData.setOfficeAddress(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_E_REMARKS_COLUMN_INDEX:
						delegatesUserData.setRemarks(cell.getStringCellValue());
						break;
					}

				});
				
				delegatesUserDataList.add(delegatesUserData);
			});
			workbook.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return delegatesUserDataList;
	}

	
	// Appendix F - MLA/MP Users excel template parsing.
	public static List<ImsUser> parseTemplateF(InputStream fileStream) {

		List<ImsUser> mlaMpUserDataList = new ArrayList<>();
		try {
			Workbook workbook = new XSSFWorkbook(fileStream);
			Sheet sheet = workbook.getSheetAt(0);

			sheet.forEach(row -> {
				ImsUser mlaMpUserData = new ImsUser();
				row.cellIterator().forEachRemaining(cell -> {
					switch (cell.getColumnIndex()) {
					case ExcelTemplateConstants.APDX_F_EMP_ID_COLUMN_INDEX:
						mlaMpUserData.setEmpNo(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_F_CONSTITUENCY_COLUMN_INDEX:
						mlaMpUserData.setConstituency(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_F_SALUTAION_COLUMN_INDEX:
						mlaMpUserData.setSalutation(new Salutation(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_F_NAME_COLUMN_INDEX:
						mlaMpUserData.setName(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_F_MOBILE_NO_COLUMN_INDEX:
						mlaMpUserData.setMobileNo(
								(cell.getCellType() == CellType.NUMERIC) ? String.valueOf(cell.getNumericCellValue())
										: cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_F_EMAIL_COLUMN_INDEX:
						mlaMpUserData.setEmail(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_F_MARITAL_STATUS_COLUMN_INDEX:
						mlaMpUserData.setMaritalStatus(new MaritalStatus(Integer.valueOf(cell.getStringCellValue())));
						break;
					case ExcelTemplateConstants.APDX_F_ADDRESS_COLUMN_INDEX:
						mlaMpUserData.setOfficeAddress(cell.getStringCellValue());
						break;
					case ExcelTemplateConstants.APDX_F_REMARKS_COLUMN_INDEX:
						mlaMpUserData.setRemarks(cell.getStringCellValue());
						break;
					}

				});
				
				mlaMpUserDataList.add(mlaMpUserData);
			});
			workbook.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return mlaMpUserDataList;
	}

}
