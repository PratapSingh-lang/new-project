package in.co.bel.ims.service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.bel.ims.data.entity.Appendix;
import in.co.bel.ims.data.repository.AppendixRepository;
import in.co.bel.ims.service.fwk.ImsServiceTemplate;

@RestController
@RequestMapping("/appendix")
public class AppendixController extends ImsServiceTemplate<Appendix, AppendixRepository>{

}
