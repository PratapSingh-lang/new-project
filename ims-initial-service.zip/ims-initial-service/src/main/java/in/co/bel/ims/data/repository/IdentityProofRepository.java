package in.co.bel.ims.data.repository;

import in.co.bel.ims.data.entity.IdentityProof;
import in.co.bel.ims.service.fwk.ImsJPATemplate;

public interface IdentityProofRepository extends ImsJPATemplate<IdentityProof> {
   
}

