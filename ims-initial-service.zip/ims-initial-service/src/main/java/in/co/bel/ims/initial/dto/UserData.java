package in.co.bel.ims.initial.dto;

import java.time.LocalDateTime;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import in.co.bel.ims.data.entity.MaritalStatus;
import in.co.bel.ims.data.entity.Role;


public class UserData  {

	private int id;
	private String designation;
	private String office;
	private Role role;
	private String mobileNo;
	private String email;
	private String name;
	private Date appointmentDate;
	private String basicPay;
	private String residentialAddress;
	private String officeAddress;
	private String department;
	private Integer loginAttempts = 0;
	private Integer loggedIn = 0;
	private Boolean locked = false;
	private LocalDateTime lastLogin;
	private LocalDateTime lastLocked;
	private MaritalStatus maritalStatus;
	private int status = 1;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	public String getOffice() {
		return office;
	}
	public void setOffice(String office) {
		this.office = office;
	}
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getBasicPay() {
		return basicPay;
	}
	public void setBasicPay(String basicPay) {
		this.basicPay = basicPay;
	}
	public String getResidentialAddress() {
		return residentialAddress;
	}
	public void setResidentialAddress(String residentialAddress) {
		this.residentialAddress = residentialAddress;
	}
	public String getOfficeAddress() {
		return officeAddress;
	}
	public void setOfficeAddress(String officeAddress) {
		this.officeAddress = officeAddress;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Integer getLoginAttempts() {
		return loginAttempts;
	}
	public void setLoginAttempts(Integer loginAttempts) {
		this.loginAttempts = loginAttempts;
	}
	public Integer getLoggedIn() {
		return loggedIn;
	}
	public void setLoggedIn(Integer loggedIn) {
		this.loggedIn = loggedIn;
	}
	public Boolean getLocked() {
		return locked;
	}
	public void setLocked(Boolean locked) {
		this.locked = locked;
	}
	public LocalDateTime getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(LocalDateTime lastLogin) {
		this.lastLogin = lastLogin;
	}
	public LocalDateTime getLastLocked() {
		return lastLocked;
	}
	public void setLastLocked(LocalDateTime lastLocked) {
		this.lastLocked = lastLocked;
	}
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	public MaritalStatus getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(MaritalStatus maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
}
