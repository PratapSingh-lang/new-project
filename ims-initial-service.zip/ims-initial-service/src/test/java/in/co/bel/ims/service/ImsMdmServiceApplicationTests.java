package in.co.bel.ims.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImsMdmServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
