package com.bel.asp.config;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.google.common.base.Predicate;

import springfox.documentation.RequestHandler;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Contact;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
@Configuration
@EnableSwagger2
@ComponentScan()
public class SwaggerConfig {
	   
	/*
	 * this class is use to configure swagger
	 */
//	@Bean
//	   public Docket productApi() {
//	      return new Docket(DocumentationType.SWAGGER_2).select()
//	         .apis((Predicate<RequestHandler>) RequestHandlerSelectors.basePackage("com.bel.asp"))
//	         .build()
//	         .apiInfo(getApiInformation());
//	   }
	   @Bean
	   public Docket api() {
	       return new Docket(DocumentationType.SWAGGER_2)
	         .apiInfo(getApiInformation())
//	         .securityContexts(Arrays.asList(securityContext()))
//	         .securitySchemes(Arrays.asList(apiKey()))
	         .select()
	         .apis((Predicate<RequestHandler>) RequestHandlerSelectors.any())
//	         .paths((Predicate<String>) PathSelectors.any())
	         .build();
	   }

		private ApiInfo getApiInformation(){
        return new ApiInfo("BEL E-Sign App",
                "Name : ASP",
                "1.0",
                "API Terms of Service URL",
                new Contact("BEL ", "www.BEl.com", "BEL.Software@gmail.com"),
                "API License",
                "API License URL"
//                , null
                );
		}
		private ApiKey apiKey() { 
		    return new ApiKey("JWT", "Authorization", "header"); 
		}
		private SecurityContext securityContext() { 
		    return SecurityContext.builder().securityReferences(defaultAuth()).build(); 
		} 

		private List<SecurityReference> defaultAuth() { 
		    AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything"); 
		    AuthorizationScope[] authorizationScopes = new AuthorizationScope[1]; 
		    authorizationScopes[0] = authorizationScope; 
		    return Arrays.asList(new SecurityReference("JWT", authorizationScopes)); 
		}
}
