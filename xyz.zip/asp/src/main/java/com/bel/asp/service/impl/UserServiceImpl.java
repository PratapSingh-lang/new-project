package com.bel.asp.service.impl;



import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.bel.asp.entity.User;
import com.bel.asp.exceptions.ResourceNotFoundException;
import com.bel.asp.payload.ApiResponse;
import com.bel.asp.payload.Constants;
import com.bel.asp.payload.GetDate;
import com.bel.asp.payload.UserDto;
import com.bel.asp.payload.UserResponse;
import com.bel.asp.repo.UserRepository;
import com.bel.asp.security.CustomUserDetailService;
import com.bel.asp.service.UserService;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;
	/*
	 * Function to fetch User based on id from database
	 */
	@Override
	public UserDto getUserById(Long userId) {

		User user = userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User", " Id ", userId));
		UserDto userDto = this.userToDto(user);
		return userDto;
	}
	@Override
	public UserDto getUserByName(String username) {
		
		User user = this.userRepository.findByUsername(username)
					.orElseThrow(() -> new ResourceNotFoundException("User", " userName ", username));
		return this.userToDto(user);
	}
	/*
	 * Function to create User into database
	 */
	@Override
	public UserDto createUser(UserDto userDto) {
		
		String encodedPassword = passwordEncoder(userDto.getPassword());
		userDto.setPassword(encodedPassword);
		User user = this.dtoToUser(userDto);
		user.setCreated_date(new Date());
		Date expiry_date = new GetDate().getExpiryDate(new Date());
		user.setExpiry_date(expiry_date);
		user.setRole(Constants.ROLE_NORMAL_USER);
		user.setStatus(new GetDate().compareDate(expiry_date));
		User savedUser = userRepository.save(user);
		return this.userToDto(savedUser);
	}
	/*
	 * Function to convert User object to UserResponse object 
	 */
	private UserResponse userToUserResponse(User user) {
		UserResponse userResponse = this.modelMapper.map(user, UserResponse.class);
		return userResponse;
	}
	
	/*
	 * Function to convert User object to UserDto object 
	 */
	private UserDto userToDto(User user) {
		UserDto userDto = this.modelMapper.map(user, UserDto.class);	
		return userDto;
	}
	
	/*
	 * Function to convert User object to UserDto object 
	 */
	private User dtoToUser(UserDto userDto) {
		User user = this.modelMapper.map(userDto, User.class);
		return user;
	}
	
	/*
	 * Function for user login implementation  
	 */
//	@Override
//	public  ApiResponse loginUser(UserDto userDto) {
//		User user = this.dtoToUser(userDto);
//		Optional<User> existedUser = Optional.of(userRepository.findByUsername(user.getUsername())
//				.orElseThrow(() -> new ResourceNotFoundException("User ", " userName : " + user.getUsername(), 0)));
//		if(existedUser != null)
//		{
//			if(passwordEncoder.matches(user.getPassword(), existedUser.get)) {
//				return new ApiResponse(Constants.LOGIN_SUCCESSFUL, true);
//			}else {
//				return new ApiResponse(Constants.INCORRECT_USER_PASSWORD,false);
//			}
//		}
//		return new ApiResponse(Constants.USER_NOT_REGISTERED,false);
//	}
//	
	private String passwordEncoder(String password) {
		return this.passwordEncoder.encode(password);	
	}
	/*
	 * Function Implementation to fetch all users with details from database
	 */
	@Override
	public List<UserDto> findAllUser() {
		List<User> users = this.userRepository.findAll();
		List<UserDto> userResponse = users.stream().map((user) -> this.userToDto(user)).collect(Collectors.toList());
		return userResponse;
	}
	/*
	 * Function for update user  
	 */
	@Override
	public UserDto updateUser(UserDto userDto) {
		// TODO Auto-generated method stub
		User user = this.dtoToUser(userDto);
		User findByUsername = this.userRepository.findByUsername(user.getUsername())
				.orElseThrow(() -> new ResourceNotFoundException("User", "userName", user.getUsername()));
			findByUsername.setDepartment(user.getDepartment());
			findByUsername.setEmail(user.getEmail());
			findByUsername.setFirst_name(user.getFirst_name());
			findByUsername.setLast_name(user.getLast_name());
			if(user.getPassword() != null) {
				findByUsername.setPassword(passwordEncoder(user.getPassword()));
			}
			findByUsername.setPhone_number(user.getPhone_number());
			
			User updateUser = this.userRepository.save(findByUsername);
			return this.userToDto(updateUser);
	}
	/*
	 * function to delete User
	 */
	@Override
	public void  delete(UserDto userDto) {
		// TODO Auto-generated method stub
		
		User user = this.userRepository.findByUsername(this.dtoToUser(userDto).getUsername())
				.orElseThrow(() -> new ResourceNotFoundException("User", "userName", this.dtoToUser(userDto).getUsername()));
		this.userRepository.delete(user);
	}
	/*
	 * function to delete All users
	 */
	public void deleteAll() {
		this.userRepository.deleteAll();
	}
}
