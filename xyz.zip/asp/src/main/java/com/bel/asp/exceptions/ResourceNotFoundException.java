package com.bel.asp.exceptions;

public class ResourceNotFoundException extends RuntimeException  {

	String resourceName;
	String fieldName;
	long fieldValue;
	String fieldname;

	public ResourceNotFoundException(String resourceName, String fieldName, long fieldValue) {
		super(String.format("%s not found with %s : %s", resourceName, fieldName, fieldValue));
		this.resourceName = resourceName;
		this.fieldName = fieldName;
		this.fieldValue = fieldValue;
	}
	public ResourceNotFoundException(String resourceName, String fieldName, String fieldname) {
		super(String.format("%s not found with %s : %s", resourceName, fieldName, fieldname));
		this.resourceName = resourceName;
		this.fieldName = fieldName;
		this.fieldname = fieldname;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public String getFieldName() {
		return fieldName;
	}

//	public ResourceNotFoundException() {
//		super();
//		// TODO Auto-generated constructor stub
//	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public long getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(long fieldValue) {
		this.fieldValue = fieldValue;
	}
}
