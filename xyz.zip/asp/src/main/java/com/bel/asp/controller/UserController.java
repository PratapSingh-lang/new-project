package com.bel.asp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bel.asp.payload.UserDto;
import com.bel.asp.payload.UserResponse;
import com.bel.asp.service.UserService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import cn.licoy.encryptbody.annotation.encrypt.EncryptBody;

import com.bel.asp.entity.User;
import com.bel.asp.payload.ApiResponse;


@RestController
@RequestMapping
//(  produces = "application/xml")
@CrossOrigin(origins = "*")
//@EncryptBody
public class UserController {

	@Autowired
	private UserService userService;
	/*
	 * Function to fetch User based on name from database
	 */
	 @PostMapping("/user/username") 
	  public ResponseEntity<UserDto> findUserByUserName(@RequestBody ObjectNode objectNode){
		  String userName = objectNode.get("userName").toString();
		  userName = userName.toString().substring(1, userName.length()-1);
		  UserDto userDto = this.userService.getUserByName(userName);
		  return new ResponseEntity<UserDto>(userDto, HttpStatus.OK); }
	 
	 
	@PutMapping("/update")
	public ResponseEntity<UserDto> updateUser(@RequestBody UserDto userDto){
		UserDto createUserDto  = this.userService.updateUser(userDto);
		return new ResponseEntity<UserDto>(createUserDto, HttpStatus.OK);
	}
	  
	  
	/*
	 * Function to fetch User based on id from database
	 */
	@PostMapping("/userById")
	public ResponseEntity<UserDto> getUserById(@RequestBody ObjectNode objectNode){
			   Long userId = objectNode.get("userId").asLong();
		return ResponseEntity.ok(this.userService.getUserById(userId));
	}
	 
	/*
	 * Function to fetch ALL User from database
	 */
	@GetMapping("/users")
	public ResponseEntity<List<UserDto>> getAllUser(){
		return ResponseEntity.ok(this.userService.findAllUser());
	}
	
	
	
	/*
	 * Function to create User into database
	 */
	@PostMapping("/register")
	public ResponseEntity<UserDto> registerUser(@Valid @RequestBody UserDto userDto){
		UserDto createUserDto  = this.userService.createUser(userDto);
		
		 return new ResponseEntity<>(createUserDto , HttpStatus.CREATED);
	}
	/*
	 * function for delete user
	 */
	@DeleteMapping("/delete")
	public ResponseEntity<ApiResponse> deleteUser(@RequestBody UserDto userDto) {
		this.userService.delete(userDto);
		return new ResponseEntity<ApiResponse>(new ApiResponse("User deleted Successfully", true), HttpStatus.OK);
	}
	/*
	 * function to delete All users
	 */
	@DeleteMapping("/deleteAll")
	public ResponseEntity<ApiResponse> deleteAll(){
		this.userService.deleteAll();
		return new ResponseEntity<ApiResponse> (new ApiResponse("All Users are deleted from database", true), HttpStatus.OK);
	}
	/*
	 * Function for user login implementation  
	 */
	
	
	/*
	 * @PostMapping("/login") public
	 * ResponseEntity<ApiResponse>loginUser(@Valid @RequestBody UserDto userDto) {
	 * ApiResponse apiResponse = this.userService.loginUser(userDto); return new
	 * ResponseEntity<ApiResponse>(apiResponse, HttpStatus.OK); }
	 */
	 
}
