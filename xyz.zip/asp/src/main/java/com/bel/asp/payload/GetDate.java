package com.bel.asp.payload;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class GetDate {

	
	private static final SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT);
	public String getCurrentDate() {
		Date currentDate = new Date();
	    return formatter.format(currentDate);
	}
	
	public Date getExpiryDate(Date createdDate) {
//		 Date date = null;
//		try {
//			date = new SimpleDateFormat(Constants.DATE_TIME_FORMAT).parse(createdDate);
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}  
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(createdDate);
        calendar.add(Calendar.MONTH, 1);
        Date createdDatePlusOneMonth = calendar.getTime();
        return createdDatePlusOneMonth;
//	    return formatter.format(createdDatePlusOneMonth);
	}
	
	public String compareDate(Date expiryDate) {
//		String currentDate = new GetDate().getCurrentDate();
//		Date current_date = null;
//		Date expiry_date = null;
//		try {
//			current_date = new SimpleDateFormat(Constants.DATE_TIME_FORMAT).parse(currentDate);
//			expiry_date = new SimpleDateFormat(Constants.DATE_TIME_FORMAT).parse(expiryDate); 
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}  
		Date currentDate = new Date();
		if(currentDate.compareTo(expiryDate) <= 0)
			return Constants.ACTIVE;
		else
			return Constants.INACTIVE;
	}
	
}
