package com.bel.asp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bel.asp.entity.User;
import com.bel.asp.payload.ApiResponse;
import com.bel.asp.payload.UserDto;
import com.bel.asp.payload.UserResponse;
import com.fasterxml.jackson.databind.JsonNode;



@Service
public interface UserService {
		

	UserDto createUser(UserDto userDto);
//	ApiResponse getUserByName(String name);
//	ApiResponse loginUser(UserDto userDto);
	UserDto getUserById(Long userId);
//	UserDto getUserDtoById(Long id);
	List<UserDto> findAllUser();
//	UserDto getUserByName(JsonNode userName);
	UserDto getUserByName(String userName);
	UserDto updateUser(UserDto userDto);
	void  delete(UserDto userDto);
	void deleteAll();
}
