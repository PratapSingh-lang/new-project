package com.bel.asp.payload;

public class Constants {

	public static final String DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss";
	public static final String DUPLICATE_USER = "User is Already Registered";
	public static final String ACTIVE = "active";
	public static final String INACTIVE = "inactive";
	public static final String ROLE_ADMIN = "Admin";
	public static final String ROLE_NORMAL_USER = "Normal_User";
	public static final String LOGIN_SUCCESSFUL = "login Successful";
	public static final String INCORRECT_USER_PASSWORD = "Please enter correct user credentials";
	public static final String USER_NOT_REGISTERED = "user is not registered";
}
