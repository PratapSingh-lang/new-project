package com.bel.asp.repo;

import java.util.Optional;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.bel.asp.entity.User;
import com.fasterxml.jackson.databind.JsonNode;

@Service
@Component
@ComponentScan
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
		
//	Optional<User> findByEmail(String username);
//	@Query("select u.id from User u where u.username = :username")
//	Optional<User> findByUsername(JsonNode username);
	Optional<User> findByUsername(String username);
	User  deleteByUsername(String username);
}
