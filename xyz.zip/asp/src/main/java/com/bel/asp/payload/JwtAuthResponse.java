package com.bel.asp.payload;

import java.util.Date;

/*
 * this class is used to send jwtAuth response
 */
public class JwtAuthResponse {

	private String token;
	private String ValidTill;
	public String getValidTill() {
		return ValidTill;
	}

	public void setValidTill(String validTill) {
		ValidTill = validTill;
	}

	private String IssuedAt;
	private UserDto user;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public UserDto getUser() {
		return user;
	}

	public void setUser(UserDto user) {
		this.user = user;
	}

	public JwtAuthResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "JwtAuthResponse [token=" + token + ", ValidTill=" + ValidTill + ", IssuedAt=" + IssuedAt + ", user="
				+ user + "]";
	}


	public String getIssuedAt() {
		return IssuedAt;
	}

	public void setIssuedAt(String string) {
		IssuedAt = string;
	}
	
}
