package com.bel.asp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AspApplicationTests {

	@Test
	void contextLoads() {
	}

}
